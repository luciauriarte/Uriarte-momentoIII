<?php
session_start();
session_destroy();
include ("index.html");
?>