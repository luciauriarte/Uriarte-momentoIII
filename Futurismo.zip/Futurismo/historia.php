<?php
session_start();
session_destroy();
include ("sesion1.php");
?>